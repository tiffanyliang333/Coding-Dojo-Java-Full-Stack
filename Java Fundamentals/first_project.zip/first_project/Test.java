import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        System.out.println("My name is Tiffany Liang");
        System.out.println("I am 27 years old");
        System.out.println("My hometown is San Francisco, CA");
    }
}