package com.hoppers.receipt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoppersReceipt1Application {

	public static void main(String[] args) {
		SpringApplication.run(HoppersReceipt1Application.class, args);
	}

}
