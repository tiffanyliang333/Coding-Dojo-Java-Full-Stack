package com.login.registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
