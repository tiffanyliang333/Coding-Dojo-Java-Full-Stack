package com.book.club.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.book.club.models.Book;

public interface BookRepository extends CrudRepository<Book, Long> {
	public List<Book> findAll();

}
