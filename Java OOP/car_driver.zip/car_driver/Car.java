public class Car {
    public int gas = 10;

    public void tank() {
        System.out.println("Gas in tank: " + gas + " out of 10.");
    }
}