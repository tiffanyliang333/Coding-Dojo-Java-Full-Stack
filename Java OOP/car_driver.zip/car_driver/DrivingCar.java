public class DrivingCar{
    public static void main(String[] args){
        Driver x = new Driver();

        x.driving();
        x.driving();
        x.driving();
        x.driving();

        x.boosters();

        x.refuel();
        x.refuel();
        x.refuel();
    }
}